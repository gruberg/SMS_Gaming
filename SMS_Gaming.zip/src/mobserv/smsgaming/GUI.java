package mobserv.smsgaming;

public class GUI {

}
